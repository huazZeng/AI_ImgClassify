# Task 3
* **contractivelearing.pdf Image-pre-train.pdf** 为调研信息
* **Pretrain-BYOL.pdf Pretrain-MAE.pdf** 为提出的方案
* MAE的实现较为困难 采取**BYOL**实现